export { default } from './Footer';
