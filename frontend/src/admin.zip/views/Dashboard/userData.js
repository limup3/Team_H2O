import uuid from 'uuid/v1';

export default userData = [
  {
    id: uuid,
    name: '비트캠프1',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '111@naver.com',
    phone: '000',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id2,
    name: '비트캠프2',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '222@naver.com',
    phone: '001',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id3,
    name: '비트캠프3',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '333@naver.com',
    phone: '002',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id4,
    name: '비트캠프4',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '444@naver.com',
    phone: '003',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id5,
    name: '비트캠프5',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '555@naver.com',
    phone: '004',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id6,
    name: '비트캠프6',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '666@naver.com',
    phone: '005',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id7,
    name: '비트캠프7',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '777@naver.com',
    phone: '006',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id8,
    name: '비트캠프8',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '888@naver.com',
    phone: '007',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id9,
    name: '비트캠프9',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '999@naver.com',
    phone: '008',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: id10,
    name: '비트캠프10',
    address: '대한민국 서울시',
    age: '11',
    sex: 'm',
    email: '000@naver.com',
    phone: '009',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  
];
