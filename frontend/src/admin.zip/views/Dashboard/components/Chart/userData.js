export const userData = [
  {
    id: 1,
    name: '비트캠프1',
    address: '대한민국 서울시',
    age: '11',
    sex: 'male',
    email: '111@naver.com',
    phone: '001',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 2,
    name: '비트캠프2',
    address: '대한민국 서울시',
    age: '22',
    sex: 'male',
    email: '222@naver.com',
    phone: '002',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 3,
    name: '비트캠프3',
    address: '대한민국 서울시',
    age: '33',
    sex: 'male',
    email: '333@naver.com',
    phone: '003',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 4,
    name: '비트캠프4',
    address: '대한민국 서울시',
    age: '44',
    sex: 'male',
    email: '444@naver.com',
    phone: '004',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 5,
    name: '비트캠프5',
    address: '대한민국 서울시',
    age: '55',
    sex: 'male',
    email: '555@naver.com',
    phone: '005',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 6,
    name: '비트캠프6',
    address: '대한민국 서울시',
    age: '66',
    sex: 'male',
    email: '666@naver.com',
    phone: '006',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 7,
    name: '비트캠프7',
    address: '대한민국 서울시',
    age: '77',
    sex: 'male',
    email: '777@naver.com',
    phone: '007',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 8,
    name: '비트캠프8',
    address: '대한민국 서울시',
    age: '88',
    sex: 'male',
    email: '888@naver.com',
    phone: '008',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 9,
    name: '비트캠프9',
    address: '대한민국 서울시',
    age: '99',
    sex: 'male',
    email: '999@naver.com',
    phone: '009',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  },
  {
    id: 10,
    name: '비트캠프10',
    address: '대한민국 서울시',
    age: '00',
    sex: 'male',
    email: '000@naver.com',
    phone: '000',
    avatarUrl: '/admin_images/avatars/user_default.png',
    createdAt: 1555016400000
  }
  
]

export default userData
