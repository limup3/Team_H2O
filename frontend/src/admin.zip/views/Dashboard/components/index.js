export { default as Budget } from './Budget';
export { default as Chart } from './Chart';
export { default as TasksProgress } from './TasksProgress';
export { default as TotalProfit } from './TotalProfit';
export { default as TotalUsers } from './TotalUsers';
export { default as HospitalsMap } from './HospitalsMap';
