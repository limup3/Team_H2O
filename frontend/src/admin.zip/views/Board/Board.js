import React from 'react';

const Board = () => {
    return (
        <div>
            Board 접속
        </div>
    )
}
export default Board