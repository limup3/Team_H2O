export { default } from './DoctorProfile';
