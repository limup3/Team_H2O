
export { default as DoctorAdd} from './DoctorAdd';
export { default as DoctorDetails} from './DoctorDetails';
export { default as DoctorProfile} from './DoctorProfile';
export { default as DoctorsTable} from './DoctorsTable';
export { default as DoctorsToolbar} from './DoctorsToolbar';