export { default } from './DoctorsTable';
