export { default as HospitalInfo} from './HospitalInfo';
export { default as HospitalsList} from './HospitalsList';