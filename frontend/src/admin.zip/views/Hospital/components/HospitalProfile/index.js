export { default } from './HospitalProfile';
