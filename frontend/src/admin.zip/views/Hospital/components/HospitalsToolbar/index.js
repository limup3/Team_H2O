export { default } from './HospitalsToolbar';
