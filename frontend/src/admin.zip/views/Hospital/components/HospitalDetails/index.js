export { default } from './HospitalDetails';
