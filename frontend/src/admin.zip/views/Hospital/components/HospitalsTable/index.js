export { default } from './HospitalsTable';
